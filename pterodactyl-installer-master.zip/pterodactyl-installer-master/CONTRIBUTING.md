# Contributing

Feel free to contribute to the project by cloning the repository and sending a pull request.

As always, make sure to state the changes in the title and the comment.
